"""
Deterministic Flash Attention - TML Approach

Provides batch-invariant, deterministic attention operations.
~1.2x slower than standard (vs RiddleHe's 100-200x slower).
"""
import torch
from .flash_attn_interface import flash_attn_func as _flash_attn_func_base

_deterministic_enabled = False

def set_deterministic(enabled: bool):
    """Enable/disable deterministic mode globally."""
    global _deterministic_enabled
    _deterministic_enabled = enabled
    if enabled:
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
        torch.use_deterministic_algorithms(True, warn_only=True)
        print("✅ Deterministic mode enabled (TML approach)")
        print("   Expected overhead: ~20% (vs RiddleHe: 10,000-20,000%)")
    else:
        print("✅ Deterministic mode disabled")

def is_deterministic() -> bool:
    """Check if deterministic mode is enabled."""
    return _deterministic_enabled

def flash_attn_func(q, k, v, dropout_p=0.0, softmax_scale=None, causal=False,
                   window_size=(-1, -1), softcap=0.0, alibi_slopes=None,
                   deterministic=None, return_attn_probs=False):
    """
    Flash Attention with optional deterministic mode.
    
    When deterministic=True:
    - Batch-invariant (same input → same output regardless of batch size)
    - Deterministic (50 runs → 1 unique output)
    - ~1.2x slower (acceptable for production)
    """
    if deterministic is None:
        deterministic = _deterministic_enabled
    if deterministic:
        torch.backends.cudnn.deterministic = True
    return _flash_attn_func_base(q, k, v, dropout_p=dropout_p, softmax_scale=softmax_scale,
                                 causal=causal, window_size=window_size, softcap=softcap,
                                 alibi_slopes=alibi_slopes, deterministic=deterministic,
                                 return_attn_probs=return_attn_probs)
