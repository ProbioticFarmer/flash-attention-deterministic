#!/bin/bash
SITE=$(python -c "import site; print(site.getsitepackages()[0])")
cp -r flash_attn "$SITE/"
echo "✅ Installed!"
